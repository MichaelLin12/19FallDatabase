package com.example.dao;

import java.awt.print.Paper;
import java.util.ArrayList;
import java.util.List;
import com.example.entity.*;
import com.example.entity.Number;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.mapper.ConferenceMapper;


@Component
public class DashboardDAO {
	@Autowired
	private ConferenceMapper companyMapper;
	
	public List<Dashboard> getdashboardList() {
		
		List<Dashboard> paperList = new ArrayList<Dashboard>();
		
		paperList = companyMapper.getPaperList();
		
		return paperList;
	}

	public List<Dashboard> getdashboardList(Number num) {
		List<Dashboard> paperList = new ArrayList<Dashboard>();
		
		paperList = companyMapper.getPaperListAnother(num);
		
		return paperList;
	}
	
}