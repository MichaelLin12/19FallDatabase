package com.example.entity;

public class Number {
	private String number;

	public Number(String number) {
		super();
		this.number = number;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	@Override
	public String toString() {
		return "Number [num=" + number + "]";
	}
}
